/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'brand-primary': '#3B82F6',
        'brand-primary-hover': '#2563EB',
        'brand-secondary': '#9CA3AF',
        'brand-secondary-hover': '#6B7280',
        'brand-light': '#FFFFFF',
        'brand-bg': '#0D1117',
        'brand-surface': '#1F2937',
        'brand-surface-hover': '#374151',
      },
      fontFamily: {
        sans: ['Open Sans', 'sans-serif'],
        heading: ['Archivo Black', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
