import React from 'react';
import Header from '../components/Header';
import { products } from '../data/mockData';
import { Product } from '../types';

const ProductCard: React.FC<{ product: Product }> = ({ product }) => (
    <div className="bg-brand-surface rounded-lg overflow-hidden flex flex-col">
        <img src={product.image} alt={product.title} className="w-full h-48 object-cover" />
        <div className="p-4 flex flex-col flex-grow">
            <h3 className="font-bold text-white font-heading uppercase">{product.title}</h3>
            <p className="text-sm text-brand-primary">{product.type}</p>
            <p className="text-sm text-brand-secondary my-2 flex-grow">{product.description}</p>
            <div className="flex justify-between items-center mt-2">
                <p className="text-lg font-bold text-white">${product.price.toFixed(2)}</p>
                <a
                   href={product.purchaseUrl}
                   target="_blank"
                   rel="noopener noreferrer"
                   className="bg-brand-primary text-white px-4 py-1.5 rounded-md text-sm font-semibold hover:bg-brand-primary-hover transition-colors"
                   aria-label={`Buy ${product.title} on external site`}
                >
                    Buy Now
                </a>
            </div>
        </div>
    </div>
);

const StorePage: React.FC = () => {
    return (
        <div>
            <Header title="Store" subtitle="Merch, Music & Art" />
            <div className="p-4 border-b border-white/10 bg-brand-surface">
                 <p className="text-brand-secondary text-center text-sm">
                    You will be redirected to an external site (Bandcamp, Amazon, etc.) to complete your purchase.
                </p>
            </div>
            <div className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {products.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default StorePage;