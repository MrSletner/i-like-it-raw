
import React from 'react';
import AiBioGenerator from '../components/AiBioGenerator';

const Logo = () => (
    <svg width="100%" height="auto" viewBox="0 0 340 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="max-w-[240px] inline-block">
        <text
            fontFamily="'Archivo Black', sans-serif"
            fontSize="80"
            fill="white"
            x="5"
            y="75"
            className="tracking-tighter"
        >
            RAW <tspan fill="#3B82F6">B</tspan>
        </text>
    </svg>
);


const HomePage: React.FC = () => {
  return (
    <div>
      <div className="p-4 pt-8">
        <div className="text-center mb-6">
            <Logo />
        </div>

        <div className="flex flex-col items-center text-center my-6">
            <div className="w-64 h-64 rounded-full overflow-hidden mb-6 shadow-2xl border-4 border-brand-surface">
                <img 
                    src="https://f4.bcbits.com/img/a2457008833_2.jpg" 
                    alt="Cover art for the album Tabula Rasa by Dookie Trackshoes, featuring a colorful, abstract geometric design." 
                    className="w-full h-full object-cover"
                />
            </div>
            <h2 className="text-3xl font-bold text-white font-heading uppercase tracking-wider">Welcome</h2>
            <p className="text-brand-secondary">Explore the world of a PNW original.</p>
        </div>
        
        <div className="my-8 text-center">
            <h3 className="font-heading text-xl uppercase tracking-wider text-brand-primary mb-3">About the Artist</h3>
             <p className="text-brand-secondary mb-4 leading-relaxed max-w-xl mx-auto">
               Mr. Sletner, aka Raw B, is a one-man musical force, seamlessly fusing hip-hop and electronic music with a blend of originality, intellect, humor, and unapologetic honesty. With nearly three decades of experience in the Pacific Northwest music scene, he's a dynamic presence, serving as a producer, musician, DJ, emcee, and performer. His independent journey has seen him distribute over 250,000 copies of his solo works, showcasing his unwavering determination. A member of esteemed music groups like Massive Verbal Assault, DPS, The Boxcutters, and the III Kings, Raw B has consistently pushed musical boundaries. With a penchant for intelligent and witty lyricism, his thought-provoking music makes you dance, laugh, cry, and contemplate, often all in one track. Raw B is a modern-day virtuoso, embodying the enduring power of artistic evolution, infusing hip-hop with authentic flavor while relentlessly exploring the boundaries of musical expression.
            </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 my-8">
          <a
            href="https://mrsletner.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 text-center bg-brand-primary hover:bg-brand-primary-hover text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200"
            aria-label="Visit the official website, MrSletner.com (opens in a new tab)"
          >
            Visit MrSletner.com
          </a>
          <a
            href="https://linktr.ee/mrsletner"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 text-center bg-brand-secondary hover:bg-brand-secondary-hover text-brand-bg font-bold py-3 px-4 rounded-lg transition-colors duration-200"
            aria-label="Find more on Linktree (opens in a new tab)"
          >
            Find More on Linktree
          </a>
        </div>

        <div className="my-8">
          <h3 className="font-heading text-xl uppercase tracking-wider text-brand-primary mb-4 text-center">AI Persona Generator</h3>
          <AiBioGenerator />
        </div>

      </div>
    </div>
  );
};

export default HomePage;