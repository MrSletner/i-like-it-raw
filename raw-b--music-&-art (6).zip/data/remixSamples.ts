import { RemixSample } from '../types';

export const remixSamples: RemixSample[] = [
  {
    id: 'drums_1',
    name: 'Drums 1',
    category: 'Drums',
    url: 'https://storage.googleapis.com/fpl-assets/drum_loop_1.mp3',
  },
  {
    id: 'drums_2',
    name: 'Drums 2',
    category: 'Drums',
    url: 'https://storage.googleapis.com/fpl-assets/drum_loop_2.mp3',
  },
  {
    id: 'drums_3',
    name: 'Drums 3',
    category: 'Drums',
    url: 'https://storage.googleapis.com/fpl-assets/drum_loop_3.mp3',
  },
  {
    id: 'bass_1',
    name: 'Bass 1',
    category: 'Bass',
    url: 'https://storage.googleapis.com/fpl-assets/bass_loop_1.mp3',
  },
  {
    id: 'bass_2',
    name: 'Bass 2',
    category: 'Bass',
    url: 'https://storage.googleapis.com/fpl-assets/bass_loop_2.mp3',
  },
  {
    id: 'bass_3',
    name: 'Bass 3',
    category: 'Bass',
    url: 'https://storage.googleapis.com/fpl-assets/bass_loop_3.mp3',
  },
  {
    id: 'synth_1',
    name: 'Synth 1',
    category: 'Synth',
    url: 'https://storage.googleapis.com/fpl-assets/synth_loop_1.mp3',
  },
  {
    id: 'synth_2',
    name: 'Synth 2',
    category: 'Synth',
    url: 'https://storage.googleapis.com/fpl-assets/synth_loop_2.mp3',
  },
  {
    id: 'synth_3',
    name: 'Synth 3',
    category: 'Synth',
    url: 'https://storage.googleapis.com/fpl-assets/synth_loop_3.mp3',
  },
  {
    id: 'vocals_1',
    name: 'Vocals 1',
    category: 'Vocals',
    url: 'https://storage.googleapis.com/fpl-assets/vocal_loop_1.mp3',
  },
  {
    id: 'vocals_2',
    name: 'Vocals 2',
    category: 'Vocals',
    url: 'https://storage.googleapis.com/fpl-assets/vocal_loop_2.mp3',
  },
  {
    id: 'vocals_3',
    name: 'Vocals 3',
    category: 'Vocals',
    url: 'https://storage.googleapis.com/fpl-assets/vocal_loop_3.mp3',
  },
];
