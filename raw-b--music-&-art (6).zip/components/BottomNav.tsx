
import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon, MusicIcon, MediaIcon, StoreIcon, RemixIcon, SupportIcon } from '../constants/icons';

const BottomNav: React.FC = () => {
  const navItems = [
    { path: '/', label: 'Home', icon: HomeIcon },
    { path: '/music', label: 'Music', icon: MusicIcon },
    { path: '/remix', label: 'Remix', icon: RemixIcon },
    { path: '/media', label: 'Media', icon: MediaIcon },
    { path: '/store', label: 'Store', icon: StoreIcon },
    { path: '/support', label: 'Support', icon: SupportIcon },
  ];

  const activeLinkClass = 'text-brand-primary';
  const inactiveLinkClass = 'text-brand-secondary hover:text-brand-light';

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-16 bg-brand-surface/80 backdrop-blur-sm border-t border-white/10 max-w-lg mx-auto">
      <div className="flex justify-around items-center h-full">
        {navItems.map(item => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) => 
              `flex flex-col items-center justify-center w-full transition-colors duration-200 px-1 ${isActive ? activeLinkClass : inactiveLinkClass}`
            }
          >
            <item.icon className="w-6 h-6" />
            <span className="text-xs mt-1">{item.label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;
