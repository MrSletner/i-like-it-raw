
import { GoogleGenAI } from "@google/genai";
import type { VercelRequest, VercelResponse } from '@vercel/node';

// This function will be the serverless function handler
export default async function handler(req: VercelRequest, res: VercelResponse) {
    if (req.method !== 'POST') {
        res.setHeader('Allow', 'POST');
        return res.status(405).json({ message: 'Only POST requests are allowed' });
    }

    const { persona } = req.body;

    if (!persona || typeof persona !== 'string') {
        return res.status(400).json({ error: 'Persona is required and must be a string.' });
    }

    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        console.error("API_KEY environment variable not set on the server.");
        return res.status(500).json({ error: "Server configuration error." });
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are a creative writer specializing in edgy, short musician bios (under 75 words) for an independent artist from the Pacific Northwest. Your tone should match the artist's persona.
- For "Raw B", think gritty, urban hip-hop.
- For "Mr Sletner", think introspective, acoustic folk.
- For "Dookie Trackshoes", think quirky, experimental lo-fi beats.
- For "III Kings", think a confident, regal hip-hop group.`;

    const userPrompt = `Write a bio for the artist persona: ${persona}.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: userPrompt,
            config: {
                systemInstruction,
                temperature: 0.8,
                topP: 0.9,
                maxOutputTokens: 150,
                thinkingConfig: { thinkingBudget: 50 },
            }
        });
        
        const bio = response.text;
        return res.status(200).json({ bio });

    } catch (error) {
        console.error("Error generating bio with Gemini API:", error);
        return res.status(500).json({ error: "Failed to generate bio." });
    }
}
