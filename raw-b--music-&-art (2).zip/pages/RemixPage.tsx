import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import * as Tone from 'tone';
import Header from '../components/Header';
import { remixSamples } from '../data/remixSamples';
import { RemixSample, SampleCategory } from '../types';

type Players = { [key: string]: Tone.Player };

const RemixPage: React.FC = () => {
    const [isLoaded, setIsLoaded] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [activeSamples, setActiveSamples] = useState<Set<string>>(new Set());
    
    const playersRef = useRef<Players>({});

    const categorizedSamples = useMemo(() => {
        const categories: { [key in SampleCategory]?: RemixSample[] } = {};
        for (const sample of remixSamples) {
            if (!categories[sample.category]) {
                categories[sample.category] = [];
            }
            categories[sample.category]!.push(sample);
        }
        return categories;
    }, []);

    useEffect(() => {
        const setupPlayers = async () => {
            const players: Players = {};
            remixSamples.forEach(sample => {
                players[sample.id] = new Tone.Player({
                    url: sample.url,
                    loop: true,
                }).toDestination();
            });
            playersRef.current = players;

            await Tone.loaded();
            setIsLoaded(true);
        };

        setupPlayers();

        return () => {
            if (Tone.Transport.state === 'started') {
                Tone.Transport.stop();
            }
            Object.values(playersRef.current).forEach(player => {
                if (player && !player.disposed) {
                   player.dispose();
                }
            });
            playersRef.current = {};
        };
    }, []);

    useEffect(() => {
        if (!isLoaded) return;
        if (isPlaying) {
            Tone.Transport.start();
        } else {
            Tone.Transport.stop();
        }
    }, [isPlaying, isLoaded]);

    const toggleSample = useCallback((sampleId: string) => {
        const player = playersRef.current[sampleId];
        if (!player || !isLoaded) return;

        setActiveSamples(prevActiveSamples => {
            const newActiveSamples = new Set(prevActiveSamples);
            if (newActiveSamples.has(sampleId)) {
                player.stop();
                newActiveSamples.delete(sampleId);
            } else {
                player.sync().start(0);
                newActiveSamples.add(sampleId);
            }
            return newActiveSamples;
        });
    }, [isLoaded]);

    const handlePlayStop = async () => {
        if (!isLoaded) return;
        if (Tone.context.state !== 'running') {
            await Tone.start();
        }
        setIsPlaying(prev => !prev);
    };
    
    const orderedCategories: SampleCategory[] = ['Drums', 'Bass', 'Synth', 'Vocals'];

    const playStopButtonClasses = `
        w-24 px-4 py-2 text-lg font-bold rounded-lg transition-all duration-200 
        focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-surface focus:ring-brand-primary 
        disabled:bg-brand-surface disabled:text-brand-secondary/50 disabled:cursor-not-allowed border-2
        ${isPlaying ? 'bg-brand-primary text-white border-brand-primary' : 'bg-brand-surface text-white border-brand-secondary'}
    `;

    return (
        <div>
            <Header title="Remix Lab" subtitle="Create your own mix" />
            <div className="p-4">
                <div className="bg-brand-surface p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-bold font-heading uppercase text-brand-primary">Remix Controls</h2>
                        <button
                            onClick={handlePlayStop}
                            disabled={!isLoaded}
                            className={playStopButtonClasses.trim()}
                        >
                            {isLoaded ? (isPlaying ? 'STOP' : 'PLAY') : '...'}
                        </button>
                    </div>

                    {!isLoaded && (
                         <div className="flex items-center justify-center p-6 bg-brand-bg rounded-md">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
                            <p className="ml-3 text-brand-secondary">Loading Samples...</p>
                         </div>
                    )}
                    
                    {isLoaded && (
                        <div className="space-y-6">
                            {orderedCategories.map(category => categorizedSamples[category] && (
                                <div key={category}>
                                    <h3 className="text-lg font-semibold text-brand-secondary mb-3 font-heading uppercase tracking-wide">{category}</h3>
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                        {categorizedSamples[category].map(sample => (
                                            <button
                                                key={sample.id}
                                                onClick={() => toggleSample(sample.id)}
                                                className={`p-3 rounded-md text-sm font-semibold transition-all duration-200 text-left truncate ${
                                                    activeSamples.has(sample.id)
                                                        ? 'bg-brand-primary text-white shadow-lg scale-105'
                                                        : 'bg-brand-bg text-brand-secondary hover:bg-brand-surface'
                                                }`}
                                                aria-pressed={activeSamples.has(sample.id)}
                                            >
                                                {sample.name}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default RemixPage;