import React from 'react';
import Header from '../components/Header';
import { SupportIcon } from '../constants/icons';

const SupportPage: React.FC = () => {
    return (
        <div>
            <Header title="Support the Artist" subtitle="Your contribution matters" />
            <div className="p-4 text-center">
                <div className="flex justify-center mb-6">
                    <SupportIcon className="w-16 h-16 text-brand-primary" />
                </div>
                <h2 className="text-2xl font-bold text-white font-heading uppercase tracking-wider mb-4">Keep the Art Alive</h2>
                <p className="text-brand-secondary mb-6 max-w-md mx-auto">
                    If you enjoy the music, art, and everything else here, please consider showing your support. Every contribution, big or small, helps me continue to create and share new work with the world. Thank you for being a part of this journey.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 my-6">
                    <a
                        href="https://patreon.com/therealRawB"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 text-center bg-brand-primary hover:bg-brand-primary-hover text-white font-bold py-3 px-4 rounded-lg transition-colors duration-200"
                        aria-label="Support on Patreon (opens in a new tab)"
                    >
                        Become a Patron
                    </a>
                    <a
                        href="https://ko-fi.com/rawbsletner"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 text-center bg-brand-secondary hover:bg-brand-secondary-hover text-brand-bg font-bold py-3 px-4 rounded-lg transition-colors duration-200"
                        aria-label="Buy a coffee on Ko-fi (opens in a new tab)"
                    >
                        Buy me a Coffee
                    </a>
                </div>
            </div>
        </div>
    );
};

export default SupportPage;