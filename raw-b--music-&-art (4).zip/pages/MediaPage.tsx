import React, { useState } from 'react';
import Header from '../components/Header';

const videoIds = [
    'ZkqFSCnBPFc',
    'TAPJTu9BCKM',
    'UhH8-uGS7oA',
    'uX_D1g1WS3M',
    'tJexTKPoIYI'
];

const VideosContent = () => (
    <div className="space-y-8">
        <div>
            <h3 className="text-lg font-semibold text-brand-secondary mb-3 font-heading uppercase tracking-wide">Featured Playlist</h3>
            <div className="relative overflow-hidden rounded-lg shadow-lg" style={{ paddingTop: '56.25%' /* 16:9 Aspect Ratio */ }}>
                <iframe
                    className="absolute top-0 left-0 w-full h-full"
                    src="https://www.youtube.com/embed/videoseries?si=HDEzUjIbsK_zZO-7&list=PLAmRj0EHmfW6iEwf8UCv6X93ukqr_tZv6"
                    title="YouTube video player playlist"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                ></iframe>
            </div>
        </div>

        <div>
             <h3 className="text-lg font-semibold text-brand-secondary mb-3 font-heading uppercase tracking-wide">More Videos</h3>
             <div className="space-y-6">
                {videoIds.map(id => (
                    <div key={id} className="relative overflow-hidden rounded-lg shadow-lg" style={{ paddingTop: '56.25%' }}>
                        <iframe
                            className="absolute top-0 left-0 w-full h-full"
                            src={`https://www.youtube.com/embed/${id}`}
                            title={`YouTube video player ${id}`}
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                        ></iframe>
                    </div>
                ))}
            </div>
        </div>
    </div>
);

const ArtContent = () => (
    <div className="space-y-6 text-center">
        <div className="bg-brand-surface p-6 rounded-lg shadow-lg">
             <h3 className="text-xl font-bold font-heading uppercase text-brand-primary mb-2">Visual Portfolio</h3>
             <p className="text-brand-secondary mb-4 max-w-md mx-auto">
                Explore a collection of digital art, design, and visual projects. The full portfolio is hosted on Behance and opens in a new tab.
            </p>
             <a
                href="https://www.behance.net/mrsletner"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-brand-primary hover:bg-brand-primary-hover text-white font-bold py-3 px-6 rounded-lg transition-colors duration-200"
                aria-label="View portfolio on Behance (opens in a new tab)"
            >
                View on Behance
            </a>
        </div>
        
        <div className="bg-brand-surface p-6 rounded-lg shadow-lg">
             <h3 className="text-xl font-bold font-heading uppercase text-brand-primary mb-2">Featured Project: Datachi</h3>
             <p className="text-brand-secondary mb-4 max-w-md mx-auto">
                Check out the "Datachi" project, a visual experiment in digital art and creative coding.
            </p>
             <a
                href="https://www.behance.net/gallery/230677041/Datachi"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-brand-secondary hover:bg-brand-secondary-hover text-brand-bg font-bold py-3 px-6 rounded-lg transition-colors duration-200"
                aria-label="View Datachi project on Behance (opens in a new tab)"
            >
                View Project
            </a>
        </div>
    </div>
);


const MediaPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState('videos');

    return (
        <div>
            <Header title="Media" subtitle="Videos & Art" />
            <div className="p-4">
                <div className="flex justify-center border-b border-white/10 mb-4">
                    <button 
                        onClick={() => setActiveTab('videos')}
                        className={`px-6 py-2 font-semibold transition-colors duration-200 ${activeTab === 'videos' ? 'text-brand-primary border-b-2 border-brand-primary' : 'text-brand-secondary'}`}
                    >
                        Videos
                    </button>
                    <button 
                        onClick={() => setActiveTab('art')}
                        className={`px-6 py-2 font-semibold transition-colors duration-200 ${activeTab === 'art' ? 'text-brand-primary border-b-2 border-brand-primary' : 'text-brand-secondary'}`}
                    >
                        Art
                    </button>
                </div>
                <div>
                    {activeTab === 'videos' && <VideosContent />}
                    {activeTab === 'art' && <ArtContent />}
                </div>
            </div>
        </div>
    );
};

export default MediaPage;